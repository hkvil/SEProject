function hapusCSS() {
    var h = document.head;
    var ch = document.head.childNodes;

    for (i = 0; i < ch.length; i++) {
        if (ch[i].nodeName == "STYLE") {
            if (ch[i].textContent == "#LA-07{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-08{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-09{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-10{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-11{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-12{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-13{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-14{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-15{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-16{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-17{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-18{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-19{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-20{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-21{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LA-22{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-07{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-08{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-09{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-10{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-11{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-12{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-13{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-14{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-15{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-16{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-17{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-18{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-19{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-20{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-21{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LT-22{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-07{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-08{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-09{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-10{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-11{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-12{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-13{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-14{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-15{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-16{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-17{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-18{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-19{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-20{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-21{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            } else if (ch[i].textContent == "#LB-22{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}") {
                h.removeChild(ch[i]);
            }

            console.log(ch[i].textContent);
        }
    }
}


//fungsi untuk mengganti warna
function gantiWarna(kode) {
    //ubah warna
    var css = "#" + kode.kode_lapangan + "{background:#00331e; color: white; pointer-events: none; cursor: not-allowed;}";
    var style = document.createElement('style');

    if (style.styleSheet) {
        style.styleSheet.cssText = css;
    } else {
        style.appendChild(document.createTextNode(css));
    }

    document.getElementsByTagName('head')[0].appendChild(style);
}

//get json dari tabel transaksi db srikandi via ajax
function getJSON() {
    hapusCSS();

    var date = $('#date-picker').datepicker().value();
    $.ajax({
        url: 'schedule/getdata',
        type: 'get',
        dataType: 'json',
        success: function (response) {
            for (i = 0; i < response['trans'].length; i++) {
                if (date == response['trans'][i].tanggal) {
                    gantiWarna(response['trans'][i]);
                }
            }
        }
    });

    hapusCSS();
    hapusCSS();
    hapusCSS();

}


//fungsi untuk membuat id otomatis di semua tombol jadwal
//nantinya id tombol akan berhubungan langsung dengan
//id lapangan yang ada di tabel transaksi
function buatId() {
    var jadwal = document.querySelectorAll('.tombol-pilihjadwal');
    var j = 7;

    // set id pertombol
    for (var i = 0; i < jadwal.length; i++) {
        if (i < 16) {
            if (j < 10) jadwal[i].id = "LA-0" + j;
            else jadwal[i].id = "LA-" + j;
            j++;
            if (j == 23) {
                j = 7;
            }
        } else if (i < 32) {
            if (j < 10) jadwal[i].id = "LT-0" + j;
            else jadwal[i].id = "LT-" + j;
            j++;
            if (j == 23) {
                j = 7;
            }
        } else {
            if (j < 10) jadwal[i].id = "LB-0" + j;
            else jadwal[i].id = "LB-" + j;
            j++;
            if (j == 23) {
                j = 7;
            }
        }
    }
    getJSON();
}
